# Gemini Desktop New+ template pack — v3

This separate app ZIP contains exactly three reusable New+ entries:

- `Gemini Desktop - Complete.html`: the complete offline manual, including its full Markdown source download.
- `Gemini Desktop - Editable Source Project/`: complete `content/guide.md`, bundled build tools, diagrams and licenses. Edit Markdown, then run `Build-Guide.cmd` (Python 3.9+ for rebuilding only).
- `Atlas Gemini Desktop Project Workspace/`: native root `PROJECT.md`, domain/task context, handoff, examples, verification workflow, and the complete reference manual.

## Use with PowerToys New+

1. Extract the entire ZIP into a normal folder.
2. Enable New+ in PowerToys Settings if needed.
3. Run `Install-NewPlus-Templates.cmd`. Existing entries are skipped by default. To refresh existing entries with backups, run `.\Install-NewPlus-Templates.ps1 -Overwrite` in PowerShell from the extracted folder.
4. Or choose **New+ > Open templates** and copy the three items inside `NewPlus-Templates/` into the templates folder. Copy the contents, not the enclosing folder.
5. Right-click an empty area in your working folder > **New+**, then choose one of the three entries. New+ creates a working copy.
6. Follow the copied entry's README. Persistent instructions on disk must still be supplied through the app's documented loading mechanism; ordinary Markdown links do not load content automatically.

The installer only copies files. It does not enable New+, change app settings, install AI apps, or connect accounts. This ZIP uses the same entry names as the complete seven-app pack.

App pack: https://drive.google.com/file/d/1a_gHxVXi1tk35tmM2RZ3JEtvUk-_KQOg/view?usp=drivesdk

Complete collection: https://drive.google.com/file/d/16qVAFl1TUB-T9-9idl6Qr5MdfIc6Sy1K/view?usp=sharing

`#Old/` and `#Temp/` are reserved for archives and temporary work. Canonical guide content remains complete and unchanged. Existing product-verification dates are retained.
